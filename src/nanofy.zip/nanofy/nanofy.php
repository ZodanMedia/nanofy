<?php
/**
 * Nanofy (once known as the Zodan Doofpot)
 * Minifies uploaded files to the absolute minimum
 * Or does nothing, put negatively.
 * 
 * Crafted by Zodan in 2002. Kicked back to life in 2011.
 *
 * Accepts a file-upload post from any file, tries to find a filename,
 * else will make up something to return. Or spits an error message if no
 * post was made or an empty form is posted.
 * Returns a filename or an error message as json data.
 * 
 * Accepts "download" as a get variable, tries to find a filename,
 * else will make up something to return.
 * Returns a zip as a downloadable file.
 *
 * (c) copyright (pfff) 2002 Zodan [zodan.nl]
 *
 */
 
 /* --------------------------------------------------------
  * 
  * What? You weren't seriously thinking of downloading this
  * code and actually *do* something with it, were you?
  *
  * If you are thinking of a serious project, don't hesitate
  * to contact us: http://zodan.nl/
  *
  */